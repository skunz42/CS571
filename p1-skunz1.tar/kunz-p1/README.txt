Name: Sean Kunz
Email: skunz1@binghamton.edu

Code was tested on remote.cs.binghamton.edu

Compile with make, execute by running ./calc

Example test files are included (works as expected for all test files)
